import matplotlib.pyplot as plt
import pandas as pd
import tensorflow as tf
from PIL import Image
import numpy as np
import os
import sys
from zipfile import ZipFile
if sys.version_info >= (3, 0):
    import configparser as ConfigParser
else:
    import ConfigParser

#import initail variable set from config file

input_images_path = ''
output_images_path = ''
tmp_images_path = ''
loc_train_solution_filename = ''
loc_val_solution_filename = ''
loc_input_images_filename = ''
loc_synset_mapping_path = ''
input_images = list()

_settings_dir = "."
configFilePath = os.path.join(_settings_dir, "setting.ini")
if os.path.exists(configFilePath):
    try:
        configParser = ConfigParser.ConfigParser()
        configParser.read(configFilePath)
        config_items = dict(configParser.items("global"))

        input_images_path = config_items['input_image_path']
        output_images_path = config_items['output_image_path']
        loc_synset_mapping_path = config_items['loc_synset_mapping_path']

        loc_train_solution_filename = config_items['loc_train_solution']
        loc_val_solution_filename = config_items['loc_val_solution']
        loc_input_images_filename = config_items['loc_input_images']
        if output_images_path != '':
            if not os.path.isdir(output_images_path):
                os.mkdir(output_images_path)


    except ConfigParser.Error as e:
        print("\nError parsing config file: " + configFilePath)
        print(str(e))
        exit(1)
#

#read files from input-directory
def getInputImages(strDir):
    lst_file = list()
    for r, d, f in os.walk(strDir):
        for file in f:
            if '.JPEG' in file and file.startswith('n0'):
                input_images.append(str(os.path.join(r, file)))
        for subdir in d:
            if subdir.startswith('n0'):
                getInputImages(str(os.path.join(r, subdir)))
#


getInputImages(input_images_path)

#processing func part

def ExpPreCell(df, colname):
    df = df[df.columns[:-1]].join(df[colname].str.split(' ', expand=True))

    renamed_cols = list(df.columns[3:])
    labels = ['lb', 'xmin', 'ymin', 'xmax', 'ymax']

    for i in range(int(len(renamed_cols) / 5)):
        renamed_cols[i * 5:i * 5 + 5] = [lb + str(i) for lb in labels]

    df.columns = list(df.columns[0:3]) + renamed_cols
    num_cols = (df.columns.shape[0] - 3) // 5
    for i in range(num_cols):
        df['xmin{}'.format(i)] = df['xmin{}'.format(i)].astype(float) / df.Width.astype(int)
        df['ymin{}'.format(i)] = df['ymin{}'.format(i)].astype(float) / df.Height.astype(int)
        df['xmax{}'.format(i)] = df['xmax{}'.format(i)].astype(float) / df.Width.astype(int)
        df['ymax{}'.format(i)] = df['ymax{}'.format(i)].astype(float) / df.Height.astype(int)

    return df

def PrsSynsetMap(path):
    synset_map = {}
    with open(path, 'r') as fp:
        lines = fp.readlines()
        for line in lines:
            parts = line.split(' ')
            synset_map[parts[0]] = [label.strip() for label in ' '.join(parts[1:]).split(',')]
        return synset_map

def GenSynset2Map(synset_mapping):
    synset_to_int_map = {}
    for index, (key, val) in enumerate(synset_mapping.items()):
        synset_to_int_map[key] = index
    return synset_to_int_map


def Gen2SynsetMap(synset_mapping):
    int_to_synset_map = {}
    for index, (key, val) in enumerate(synset_mapping.items()):
        int_to_synset_map[index] = key
    return int_to_synset_map

def ProcImg(img, input_img, img_col, fig):
    img_path = input_img
    filename = os.path.basename(input_img).split('.')[0]
    row = img_col.loc[img_col['ImageId'] == filename]
    synset = row.ImageId.values[0].split('_')[0]

    img_name = [img_path]
    print('ready:{}'.format(input_img))
    sess = tf.compat.v1.Session()
    coord = tf.train.Coordinator()
    #threads = tf.train.start_queue_runners(sess=sess, coord=coord)

    boxes = []
    num_cols = (row.columns.shape[0] - 3) // 5

    for i in range(num_cols):
        if row['lb{}'.format(i)].values[0] is not None:
            boxes.append([
                row['ymin{}'.format(i)].values[0],
                row['xmin{}'.format(i)].values[0],
                row['ymax{}'.format(i)].values[0],
                row['xmax{}'.format(i)].values[0]])
    #     boxes = [[row.ymin0.values[0], row.xmin0.values[0], row.ymax0.values[0], row.xmax0.values[0]]]
    box = tf.constant([boxes])
    img = tf.convert_to_tensor(img)
    img = tf.reshape(img, [1, 299, 299, 3])

    image_bilinear = tf.image.draw_bounding_boxes(img, box)
    image_bilinear = tf.reshape(image_bilinear, [299, 299, 3])

    ax = fig.add_subplot()
    ax.imshow(sess.run(image_bilinear))
    ax.axis('off')
    ###
    fig.savefig(output_images_path + synset)
    ###

    print('success:{}'.format(input_img))
    sess.close()
#

if __name__ == '__main__':
    for input_img in input_images:
        plt.close('all')
        fig, ax = plt.subplots(1, 1, figsize=(20, 20))
        ax = fig.add_subplot()
        ax.imshow(plt.imread(input_img))
        ax.axis('off')

        loc_train_solution = pd.read_csv(loc_train_solution_filename)
        loc_val_solution = pd.read_csv(loc_val_solution_filename)
        loc_input_images = pd.read_csv(loc_input_images_filename)

        loc_input_images.head()
        loc_train_solution.head()
        loc_val_solution.head()


        loc_input_images_xp = ExpPreCell(loc_input_images, 'PredictionString')
        loc_input_images_xp.head()

        synset_mapping = PrsSynsetMap(loc_synset_mapping_path)
        synset_to_int = GenSynset2Map(synset_mapping)
        int_to_synset = Gen2SynsetMap(synset_mapping)

        len(synset_mapping)

        for index, (key, val) in enumerate(synset_mapping.items()):
            if (index > 5):
                break

        for index, (key, val) in enumerate(synset_to_int.items()):
            if (index > 5):
                break

        for index, (key, val) in enumerate(int_to_synset.items()):
            if (index > 5):
                break

        training_set = ExpPreCell(loc_train_solution, 'PredictionString')

        # rows = training_set.lb0.shape[0]
        # cols = 17

        plt.close('all')
        fig, ax = plt.subplots(2, 2, sharex='col', sharey='row', figsize=(20, 20))
        img = Image.open(input_img)
        img = np.array(img.resize((299, 299))) / 255
        img = img.astype(np.float32)
        ProcImg(img, input_img, loc_input_images_xp, fig)